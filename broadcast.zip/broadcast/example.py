from broadcast import broadcast
import time
while True:
    broadcast()
    time.sleep(1)

'''
run python broadcast.py
then in a seperate terminal run this file.
'''
